import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Sortdemo';
  empId;
  empSal;
  empDep;
  empName;
  empjoiningdate;
  list:Object[]=[];
  constructor(){
  this.list.push({empId:1001,empName:'Rahul',empSal:9000,empDep:'JAVA',empjoiningdate:'6/12/2014'});
  this.list.push({empId:1010,empName:'Vikash',empSal:11000,empDep:'ORAAPS',empjoiningdate:'6/12/2017'});
  this.list.push({empId:1003,empName:'Uma',empSal:12000,empDep:'JAVA',empjoiningdate:'6/12/2010'});
  this.list.push({empId:1004,empName:'Sachin',empSal:11500,empDep:'ORAAPS',empjoiningdate:'11/12/2017'});

}
public sortedid()
{
for(let i=0;i<this.list.length;i++)
  {
    for(let j=0;j<this.list.length-1;j++)
    {if(this.list[j]["empId"]>this.list[j+1]["empId"])
    {
      let temp=this.list[j];
      this.list[j]=this.list[j+1];
      this.list[j+1]=temp;
      //[this.list[j],this.list[j+1]]=[this.list[j+1],this.list[j]];
    }

    }
  }

}
sortedname()
{
  for(let i=0;i<this.list.length;i++)
  {
    for(let j=0;j<this.list.length-1;j++)
    {if(this.list[j]["empName"]>this.list[j+1]["empName"])
    {
      let temp=this.list[j];
      this.list[j]=this.list[j+1];
      this.list[j+1]=temp;
      //[this.list[j],this.list[j+1]]=[this.list[j+1],this.list[j]];
    }

    }
  }
}
sortedsalary()
{
  for(let i=0;i<this.list.length;i++)
  {
    for(let j=0;j<this.list.length-1;j++)
    {if(this.list[j]["empSal"]>this.list[j+1]["empSal"])
    {
      let temp=this.list[j];
      this.list[j]=this.list[j+1];
      this.list[j+1]=temp;
      //[this.list[j],this.list[j+1]]=[this.list[j+1],this.list[j]];
    }

    }
  }

}
sorteddept()
{
  for(let i=0;i<this.list.length;i++)
  {
    for(let j=0;j<this.list.length-1;j++)
    {if(this.list[j]["empDep"]>this.list[j+1]["empDep"])
    {
      let temp=this.list[j];
      this.list[j]=this.list[j+1];
      this.list[j+1]=temp;
      //[this.list[j],this.list[j+1]]=[this.list[j+1],this.list[j]];
    }

    }
  }
}
sorteddate()
{
  
}
}
