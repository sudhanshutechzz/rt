export class Localbook{
    id:string;
    title:string;
    year:string;
    author:string;
    constructor(id,title,year,author)
    {
        this.id=id;
        this.title=title;
        this.year=year;
        this.author=author;
    }
}