import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import { Localbook } from '../Localbook';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  array:Localbook[]=[];
  constructor(public ap:AppComponent,public router:Router) { }

  ngOnInit(): void {
    this.array=this.ap.localbooklist;
  }
  customerForm=new FormGroup({
    id:new FormControl('enter your name',[Validators.required,Validators.minLength(4)]),
    title:new FormControl(),
    year:new FormControl(),
    author:new FormControl()
  })
  onSubmit()
  {
    let id=this.array[this.array.length-1].id+1;
    let Local=new Localbook(id,this.customerForm.get("title").value,this.customerForm.get("year").value,this.customerForm.get("author").value);
    this.array.push(Local);
    this.ap.localbooklist=this.array;
    this.router.navigate(['about']);

  }

}
