import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { Observable,throwError } from 'rxjs';
import { Localbook } from './Localbook';
import {retry,catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  mydata()
  {
    return 'This is the data from my DataService';
  }
  localurl:string='./assets/booklist.json';
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({'Content-Type':'application/json'})
  }
 GetLocalBooks():Observable<Localbook>
 {
   return this.http.get<Localbook>(this.localurl)
   .pipe(retry(1),catchError(this.errorHandl))
 }
 errorHandl(error)
 {
   console.log(error);
   return throwError(error);
 }
 baseurl:string=""
 data:Object;
 PostNewBook():any{
   console.log("inside PostNewBook() of DataService");
   this.http
   .post(
     this.baseurl,
     JSON.stringify({
       body:'bar',
       title:'foo',
       userId:1

     })

   )
   .subscribe(data=>{
     this.data=data;
   });                              
 }
}
