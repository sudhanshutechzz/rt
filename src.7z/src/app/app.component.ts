import { Component, OnInit } from '@angular/core';
import { DataService } from './data.service';
import { Router } from '@angular/router';
import { Localbook } from './Localbook';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Servicedemo';
  somedata:string='';
  localbooklist:Localbook[]=[];
  constructor(private ds:DataService,private router:Router){

  }
  ngOnInit()
  {
this.somedata=this.ds.mydata();
this.loadlocalbooks();
this.router.navigate(['about']);

  }
  loadlocalbooks(){
    return this.ds.GetLocalBooks().subscribe((data:any)=>{
      this.localbooklist=data;
    }
    )
  }

}
