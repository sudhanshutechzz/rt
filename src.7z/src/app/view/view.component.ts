import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { Localbook } from '../Localbook';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  array:Localbook[]=[];

  constructor(public ap:AppComponent) { }

  ngOnInit(): void {
    this.array=this.ap.localbooklist;
  }
  onremove(id)
  {
    for(let i=0;i<this.ap.localbooklist.length;i++)
  {
    if(this.ap.localbooklist[i].id==id)
    {
      this.ap.localbooklist.splice(i,1);
    }
  }
  }

}
